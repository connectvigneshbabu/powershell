﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf_Notify_User
{
    public class UserNotificationMessage
    {
        public string Message;
        public int SecondsToShow;
    }
}
